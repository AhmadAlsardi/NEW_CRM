SMART MEDIA CRM -> FIGMA

1) Double-click START-FIGMA-SERVER.bat
2) Keep the black Command Prompt window OPEN.
3) Chrome opens FIGMA-SCREENS.html automatically.
4) Click any screen, for example 03 Dashboard.
5) On that screen click the Figma Chrome extension -> Capture page.
6) In the capture bar, click the Figma logo/button to send the captured page to Figma.
7) Choose/open your Figma design file and paste/import the capture when prompted by the extension.
8) Repeat for the screens you want. There are 39 prepared screen/state links.

IMPORTANT:
- Do NOT open the HTML by double-clicking index.html (file:///...). Use the BAT server.
- Each link is a separate URL, so Figma captures one screen at a time rather than one giant gallery.
- If Windows Firewall asks about Python, allow Private networks.
